#!/bin/bash

#HELP: Shows the time up
echo "%E2%8F%B1"
echo -n "It has been " ; uptime --pretty
