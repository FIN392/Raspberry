#!/bin/bash

#HELP: List of logged in users
echo "%F0%9F%91%A5"
w
