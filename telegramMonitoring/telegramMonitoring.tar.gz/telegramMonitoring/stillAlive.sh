#!/bin/bash

#
# EDITOR=nano crontab -e
#
#     (Add to beginning of file)
#
#     # telegramMonitoring: Send KEEPALIVE message at noon
#     0 12 * * * (sudo /home/pi/telegramMonitoring/stillAlive.sh)
#

# Path for telegramMonitoring
tMPath=/home/pi/telegramMonitoring

#
# Send KEEPALIVE message
#
echo -e "<code>%F0%9F%91%8D\nStill alive. Use </code>/help<code> to see the available commands</code>" | $tMPath/sendTelegramMessage.sh
