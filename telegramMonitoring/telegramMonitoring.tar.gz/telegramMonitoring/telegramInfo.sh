# Token for bot
telegramToken="1111111111:AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA"

# ID for Telegram user account
telegramId="999999999"
